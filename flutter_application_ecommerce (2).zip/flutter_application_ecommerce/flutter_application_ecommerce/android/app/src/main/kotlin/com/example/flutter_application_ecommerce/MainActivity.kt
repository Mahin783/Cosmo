package com.example.flutter_application_ecommerce

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
